This application runs on requires no python 3.4.3, it also requires no dependencies other
than what is commonly found on this version of python. Now in order to run the file you must
use the cd command to go to the location where Report_Card_Creator.py is located. From there
run the command python Report_Card_Creator.py

If the program is running correctly a prompt will appear saying "please enter the file",
the first file that should be entered is "courses.csv" once this is done press enter, then
another prompt will appear saying "please enter the file", this time enter "students.csv"
and press enter. Do this for "tests.csv" and "marks.csv" as well. Once you have entered all
four file names a new file will appear called "output.txt", this is where the report card
is found.
